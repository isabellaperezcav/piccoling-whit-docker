CREATE TABLE menu (
    id_menu int auto_increment,
    nombre VARCHAR(100),
    precio DECIMAL(10,2),
    cantidad INT(11)
);