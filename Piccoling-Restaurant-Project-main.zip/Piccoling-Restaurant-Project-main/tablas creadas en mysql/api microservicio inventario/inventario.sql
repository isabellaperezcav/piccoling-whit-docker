CREATE TABLE inventario (
  id_inventario INT AUTO_INCREMENT,
  ingrediente VARCHAR(100),
  cantidad_disponible INT,
  PRIMARY KEY (id_inventario)
);
